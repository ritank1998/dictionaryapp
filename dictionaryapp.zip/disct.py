import json
from difflib import get_close_matches
data = json.load(open("data.json","r"))
def translate(word):
    word = word.lower()
    if word in data:
        return data[word]
    elif len(get_close_matches(word, data.keys())) > 0:
         yn = input("Did you mean %s instead? Enter yes if yes, or no if no: " % get_close_matches(word, data.keys())[0])
         if yn =="yes":
            return data[get_close_matches(word, data.keys()) [0]]
         elif yn =="no":
            return "The word dosen't exists.Please do correct the spelling . Or report for any kind of extra error found. Thank you"
         else:
            return "We didn't get your entry.Check again"
    else:
        return "please check the spelling"
word = input("enter a word: ")
output =translate(word)
if type(output) == list:
    for item in output:
        print(item)
else:
    print(output)
